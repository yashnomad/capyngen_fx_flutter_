class TradeData {
  static const String stockCategory = "Metals";
  // static const String stockCategory = "Crypto";
}
