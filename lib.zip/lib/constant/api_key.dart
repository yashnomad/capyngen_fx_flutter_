const twelveDataApiKey1 = 'ce5ff06e4f574e1884e315c45942053e';
const twelveDataApiKey2 = 'd0d1822d9cfd414a89075a14cd08845b';
const twelveDataApiKey3 = 'c415cf02958d4880b84fca36c47a639a';
const twelveDataApiKey4 = '07a4949327a245e8b45943a77b548868';

/*


1. nidatek124@simerm.com
Nddx!BgcvP.9MUc
api key -
ce5ff06e4f574e1884e315c45942053e

2. gaheb42610@pacfut.com
Akshyy@123

d0d1822d9cfd414a89075a14cd08845b

3.
henoc75406@pacfut.com
Akshyy@123

c415cf02958d4880b84fca36c47a639a


4.
wigeg33655@pacfut.com

Akshyy@123
07a4949327a245e8b45943a77b548868


*/
