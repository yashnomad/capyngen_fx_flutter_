class AppVector {
  static const String appIconLogo = 'assets/image/app_icon_logo.jpg';
  static const String arrow = 'assets/image/arrow.png';
  static const String auto = 'assets/image/auto.png';
  static const String binance = 'assets/image/binance.png';
  static const String bot = 'assets/image/bot.png';
  static const String bull = 'assets/image/bull.jpg';
  static const String c = 'assets/image/c.png';
  static const String crypto = 'assets/image/crpto.jpg';
  static const String dark = 'assets/image/dark.png';
  static const String exness = 'assets/image/exness.png';
  static const String google = 'assets/image/google.png';
  static const String graph = 'assets/image/graph.jpg';
  static const String history = 'assets/image/history.png';
  static const String light1 = 'assets/image/light1.png';
  static const String line = 'assets/image/line.png';
  static const String noOrder = 'assets/image/no_order.png';
  static const String success = 'assets/image/success.json';
  static const String trading = 'assets/image/treading.jpg';
  static const String usFlag = 'assets/image/us_flag.png';
}