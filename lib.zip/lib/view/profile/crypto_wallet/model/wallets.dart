
import 'package:flutter/material.dart';

final wallets = [
  {
    "name": "Bitcoin (BTC)",
    "symbol": "BTC",
    "balance": "0.00000000",
    "usdValue": "0.00",
    "icon": Icons.currency_bitcoin
  },
  {
    "name": "Tether (USDT ERC20)",
    "symbol": "USDT",
    "balance": "0.00",
    "usdValue": "0.00",
    "icon": Icons.attach_money
  },
  {
    "name": "Bitcoin (BTC)",
    "symbol": "BTC",
    "balance": "0.00000000",
    "usdValue": "0.00",
    "icon": Icons.currency_bitcoin
  },
  {
    "name": "Tether (USDT ERC20)",
    "symbol": "USDT",
    "balance": "0.00",
    "usdValue": "0.00",
    "icon": Icons.attach_money
  },
  {
    "name": "Bitcoin (BTC)",
    "symbol": "BTC",
    "balance": "0.00000000",
    "usdValue": "0.00",
    "icon": Icons.currency_bitcoin
  },
  {
    "name": "Tether (USDT ERC20)",
    "symbol": "USDT",
    "balance": "0.00",
    "usdValue": "0.00",
    "icon": Icons.attach_money
  },
  {
    "name": "Bitcoin (BTC)",
    "symbol": "BTC",
    "balance": "0.00000000",
    "usdValue": "0.00",
    "icon": Icons.currency_bitcoin
  },
  {
    "name": "Tether (USDT ERC20)",
    "symbol": "USDT",
    "balance": "0.00",
    "usdValue": "0.00",
    "icon": Icons.attach_money
  },
  {
    "name": "Bitcoin (BTC)",
    "symbol": "BTC",
    "balance": "0.00000000",
    "usdValue": "0.00",
    "icon": Icons.currency_bitcoin
  },
  {
    "name": "Tether (USDT ERC20)",
    "symbol": "USDT",
    "balance": "0.00",
    "usdValue": "0.00",
    "icon": Icons.attach_money
  },
];