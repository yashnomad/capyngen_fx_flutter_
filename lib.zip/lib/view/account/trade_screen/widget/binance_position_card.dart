import 'package:exness_clone/provider/datafeed_provider.dart';
import 'package:exness_clone/theme/app_flavor_color.dart';
import 'package:exness_clone/services/data_feed_ws.dart' as feed_ws;
import 'package:exness_clone/view/account/buy_sell_trade/model/trade_model.dart';
import 'package:exness_clone/view/account/buy_sell_trade/model/ws_equity_data.dart'
    as eq_data;
import 'package:exness_clone/view/trade/model/trade_account.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BinancePositionCard extends StatefulWidget {
  final TradeModel trade;
  final eq_data.LiveProfit liveProfit;
  final Account activeAccount;
  final Color cardColor;
  final Color textColor;
  final Color greyText;
  final Color dividerColor;
  final bool isDark;
  final Function(TradeModel) onModify;
  final Function(TradeModel, String) onClose;

  const BinancePositionCard({
    super.key,
    required this.trade,
    required this.liveProfit,
    required this.activeAccount,
    required this.cardColor,
    required this.textColor,
    required this.greyText,
    required this.dividerColor,
    required this.isDark,
    required this.onModify,
    required this.onClose,
  });

  @override
  State<BinancePositionCard> createState() => _BinancePositionCardState();
}

class _BinancePositionCardState extends State<BinancePositionCard> {
  bool _isExpanded = false;

  final Color _binanceGreen = const Color(0xFF0ECB81);
  final Color _binanceRed = const Color(0xFFF6465D);

  @override
  Widget build(BuildContext context) {
    final isBuy = (widget.trade.bs ?? 'Buy').toLowerCase() == 'buy';
    final sideColor = isBuy ? _binanceGreen : _binanceRed;

    // Use live profit if available, otherwise 0.0 or check trade properties
    // In original code: logic was complex relating to isConnecting etc.
    // Simplifying based on passed liveProfit which should have the correct value.
    final pnlVal =
        widget.liveProfit.profit ?? widget.trade.profitLossAmount ?? 0.0;

    // Check if we should show dashes (inherited logic)
    // The original code checked provider state for 'isConnecting'.
    // Here we assume liveProfit carries the necessary info or we just display what we have.
    // If we want exact parity with "showDashes", we might need that state passed in.
    // However, liveProfit uses `orElse` in the parent so it's likely populated.

    final pnlColor = pnlVal >= 0 ? _binanceGreen : _binanceRed;
    final pnlStr = "${pnlVal >= 0 ? '+' : ''}${pnlVal.toStringAsFixed(2)}";
    final roiStr =
        "${pnlVal >= 0 ? '+' : ''}${(pnlVal * 5).toStringAsFixed(2)}%";

    const leverage = 20;
    final lotSize = widget.trade.lot ?? 0.0;
    final entryPrice = widget.trade.avg ?? 0.0;
    final marginCalc = (lotSize * entryPrice) / leverage;

    final tpStr = widget.trade.target != null
        ? widget.trade.target!.toStringAsFixed(2)
        : "--";
    final slStr =
        widget.trade.sl != null ? widget.trade.sl!.toStringAsFixed(2) : "--";

    return Container(
      decoration: BoxDecoration(
        color: widget.cardColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER (Clickable)
          InkWell(
            onTap: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: sideColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          isBuy ? "Buy" : "Sell",
                          style: TextStyle(
                            color: sideColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        widget.trade.symbol ?? "Unknown",
                        style: TextStyle(
                          color: widget.textColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const Spacer(),
                      // Optional: Icon to indicate expansion
                      Icon(
                        _isExpanded
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down,
                        color: widget.greyText,
                        size: 20,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Unrealized PNL (USDT)",
                              style: TextStyle(
                                  color: widget.greyText, fontSize: 11)),
                          const SizedBox(height: 2),
                          Text(
                            pnlStr,
                            style: TextStyle(
                              color: pnlColor,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text("ROI",
                              style: TextStyle(
                                  color: widget.greyText, fontSize: 11)),
                          const SizedBox(height: 2),
                          Text(
                            roiStr,
                            style: TextStyle(
                              color: pnlColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // BODY (Collapsible)
          if (_isExpanded) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Divider(
                  color: widget.dividerColor.withOpacity(0.3), height: 1),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildGridStat("Size", lotSize.toString(),
                          widget.textColor, widget.greyText),
                      _buildGridStat("Margin", marginCalc.toStringAsFixed(2),
                          widget.textColor, widget.greyText),
                      _buildGridStat(
                          "Entry Price",
                          entryPrice.toStringAsFixed(2),
                          widget.textColor,
                          widget.greyText),
                      Selector<DataFeedProvider, feed_ws.LiveProfit?>(
                        selector: (_, provider) =>
                            provider.liveData[widget.trade.symbol] ??
                            provider.liveData[
                                (widget.trade.symbol ?? "").toUpperCase()],
                        builder: (context, liveData, _) {
                          final currentLivePrice = isBuy
                              ? (liveData?.bid ?? entryPrice)
                              : (liveData?.ask ?? entryPrice);
                          return _buildGridStat(
                            "Mark Price",
                            currentLivePrice.toStringAsFixed(2),
                            widget.textColor,
                            widget.greyText,
                            crossAlign: CrossAxisAlignment.end,
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      _buildGridStat("TP / SL", "$tpStr / $slStr",
                          widget.textColor, widget.greyText),
                    ],
                  ),
                ],
              ),
            ),
          ],

          // FOOTER (Always Visible)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    "TP/SL",
                    Colors.green[500]!,
                    widget.dividerColor,
                    icon: Icons.edit_note,
                    isOutlined: true,
                    onTap: () => widget.onModify(widget.trade),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildActionButton(
                    "Close Position",
                    _binanceRed,
                    Colors.transparent,
                    bgColor: Colors.transparent,
                    icon: Icons.close,
                    isOutlined: true,
                    onTap: () {
                      if (widget.activeAccount.id != null) {
                        widget.onClose(widget.trade, widget.activeAccount.id!);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGridStat(
      String label, String value, Color textColor, Color greyText,
      {CrossAxisAlignment crossAlign = CrossAxisAlignment.start}) {
    return Column(
      crossAxisAlignment: crossAlign,
      children: [
        Text(label, style: TextStyle(color: greyText, fontSize: 11)),
        const SizedBox(height: 2),
        Text(value,
            style: TextStyle(
                color: textColor, fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildActionButton(String label, Color textColor, Color borderColor,
      {Color? bgColor,
      VoidCallback? onTap,
      IconData? icon,
      bool isFilled = false,
      bool isOutlined = false}) {
    final effectiveBorderColor = isOutlined ? textColor : borderColor;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: bgColor ??
              (isOutlined ? Colors.transparent : Colors.grey.shade200),
          border: Border.all(
              color: isFilled ? Colors.transparent : effectiveBorderColor,
              width: isOutlined ? 1.0 : 1.0),
          borderRadius: BorderRadius.circular(8),
          boxShadow: isFilled
              ? [
                  BoxShadow(
                    color: (bgColor ?? Colors.black).withOpacity(0.2),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  )
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 14, color: textColor),
              const SizedBox(width: 4),
            ],
            Text(label,
                style: TextStyle(
                    color: textColor,
                    fontSize: 12,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
