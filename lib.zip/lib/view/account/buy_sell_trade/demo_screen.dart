import 'package:exness_clone/view/account/widget/account_symbol_section.dart';
import 'package:flutter/material.dart';

class DemoScreen extends StatelessWidget {
  const DemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: AccountSymbolSection(),);
  }
}
